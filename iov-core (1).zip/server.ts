import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import Database from "better-sqlite3";
import { WebSocketServer, WebSocket } from "ws";
import http from "http";

const db = new Database("v2x_testing.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS test_cases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL, -- ECU, T-Box, Gateway, IVI, Full Vehicle
    type TEXT NOT NULL,     -- Automated, Manual
    protocol TEXT,          -- CAN, DoIP, V2X, Bluetooth, etc.
    description TEXT,
    steps TEXT,             -- JSON string
    test_input TEXT,
    test_tool TEXT,
    expected_result TEXT,
    automation_level TEXT,
    status TEXT DEFAULT 'Draft',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS test_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    test_case_id INTEGER,
    result TEXT,            -- Pass, Fail, Blocked
    logs TEXT,
    duration INTEGER,       -- In seconds
    executed_by TEXT,
    executed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(test_case_id) REFERENCES test_cases(id)
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );

  CREATE TABLE IF NOT EXISTS defects (
    id TEXT PRIMARY KEY,
    description TEXT NOT NULL,
    module TEXT NOT NULL,
    severity TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS assets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    status TEXT NOT NULL,
    version TEXT,
    type TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  INSERT OR IGNORE INTO settings (key, value) VALUES ('abort_on_critical_dtc', 'true');
  INSERT OR IGNORE INTO settings (key, value) VALUES ('pr_requires_sil', 'true');
`);

// Migration: Add duration column to test_runs if it doesn't exist
try {
  db.exec("ALTER TABLE test_runs ADD COLUMN duration INTEGER;");
} catch (e) {
  // Ignore error if column already exists
}

// Migration: Add steps column to test_cases if it doesn't exist
try {
  db.exec("ALTER TABLE test_cases ADD COLUMN steps TEXT;");
} catch (e) {
  // Ignore error if column already exists
}

// Migration: Add new columns if they don't exist
const columns = ['test_input', 'test_tool', 'expected_result', 'automation_level'];
columns.forEach(col => {
  try {
    db.exec(`ALTER TABLE test_cases ADD COLUMN ${col} TEXT;`);
  } catch (e) {}
});

async function startServer() {
  const app = express();
  const server = http.createServer(app);
  const wss = new WebSocketServer({ server });
  const PORT = 3000;

  app.use(express.json());

  // WebSocket connection handling
  const clients = new Set<WebSocket>();
  wss.on('connection', (ws) => {
    clients.add(ws);
    ws.on('close', () => clients.delete(ws));
  });

  const broadcast = (data: any) => {
    const message = JSON.stringify(data);
    clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(message);
      }
    });
  };

  // API Routes
  app.get("/api/test-cases", (req, res) => {
    const cases = db.prepare("SELECT * FROM test_cases ORDER BY created_at DESC").all();
    res.json(cases);
  });

  app.post("/api/test-runs", (req, res) => {
    const { test_case_id, asset_id } = req.body;
    // 模拟发起测试任务：更新用例状态为 Running
    db.prepare("UPDATE test_cases SET status = 'Running' WHERE id = ?").run(test_case_id);
    // 记录一条初始运行记录
    const info = db.prepare(
      "INSERT INTO test_runs (test_case_id, result, logs, executed_by) VALUES (?, ?, ?, ?)"
    ).run(test_case_id, 'Running', `Task initiated for asset ID: ${asset_id}`, 'User');
    
    res.json({ id: info.lastInsertRowid });
  });

  app.post("/api/test-cases", (req, res) => {
    const { title, category, type, protocol, description, steps, test_input, test_tool, expected_result, automation_level } = req.body;
    const info = db.prepare(
      "INSERT INTO test_cases (title, category, type, protocol, description, steps, test_input, test_tool, expected_result, automation_level) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
    ).run(title, category, type, protocol, description, JSON.stringify(steps), test_input, test_tool, expected_result, automation_level);
    res.json({ id: info.lastInsertRowid });
  });

  app.post("/api/test-cases/import", (req, res) => {
    const { cases } = req.body;
    const insert = db.prepare(`
      INSERT INTO test_cases (category, title, test_input, test_tool, steps, expected_result, automation_level, type, protocol)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const transaction = db.transaction((items) => {
      for (const item of items) {
        // 自动识别协议和类型
        const protocol = item.category === 'CAN总线' ? 'CAN' : 
                         item.category.includes('蓝牙') ? 'BLE' : 
                         item.category === '车云通信' ? 'Ethernet' : 
                         item.category.includes('无线电') ? 'WiFi' : 'Other';
        const type = item.automation_level === 'A' ? 'Automated' : 'Manual';
        
        insert.run(
          item.category,
          item.title,
          item.test_input,
          item.test_tool,
          JSON.stringify(item.steps.split('\n')),
          item.expected_result,
          item.automation_level,
          type,
          protocol
        );
      }
    });

    transaction(cases);
    res.json({ success: true, count: cases.length });
  });

  app.patch("/api/test-cases/:id", (req, res) => {
    const { id } = req.params;
    const { title, category, type, protocol, description, steps } = req.body;
    db.prepare(
      "UPDATE test_cases SET title = ?, category = ?, type = ?, protocol = ?, description = ?, steps = ? WHERE id = ?"
    ).run(title, category, type, protocol, description, JSON.stringify(steps), id);
    res.json({ success: true });
  });

  app.delete("/api/test-cases/:id", (req, res) => {
    const { id } = req.params;
    db.prepare("DELETE FROM test_runs WHERE test_case_id = ?").run(id);
    db.prepare("DELETE FROM test_cases WHERE id = ?").run(id);
    res.json({ success: true });
  });

  app.patch("/api/test-cases/:id/status", (req, res) => {
    const { id } = req.params;
    const { status } = req.body;
    db.prepare("UPDATE test_cases SET status = ? WHERE id = ?").run(status, id);
    
    // If it's a final state, record a test run to update stats
    if (['Passed', 'Failed', 'Blocked'].includes(status)) {
      db.prepare("INSERT INTO test_runs (test_case_id, result, executed_by) VALUES (?, ?, ?)")
        .run(id, status, 'System');
    }
    
    res.json({ success: true });
  });

  app.get("/api/stats", (req, res) => {
    const stats = {
      total: db.prepare("SELECT COUNT(*) as count FROM test_cases").get().count,
      automated: db.prepare("SELECT COUNT(*) as count FROM test_cases WHERE type = 'Automated'").get().count,
      manual: db.prepare("SELECT COUNT(*) as count FROM test_cases WHERE type = 'Manual'").get().count,
      results: db.prepare("SELECT result, COUNT(*) as count FROM test_runs GROUP BY result").all()
    };
    res.json(stats);
  });

  app.get("/api/stats/trend", (req, res) => {
    // Query real data from test_runs for the last 7 days
    const trend = db.prepare(`
      SELECT 
        date(executed_at) as date,
        COUNT(*) as total,
        SUM(CASE WHEN result = 'Passed' THEN 1 ELSE 0 END) as passed
      FROM test_runs
      WHERE executed_at >= date('now', '-7 days')
      GROUP BY date(executed_at)
      ORDER BY date ASC
    `).all();

    // Map to the format frontend expects
    const days = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
    const formatted = trend.map(t => ({
      date: days[new Date(t.date).getDay()],
      passRate: t.total > 0 ? Math.round((t.passed / t.total) * 100) : 0,
      runs: t.total
    }));

    res.json(formatted);
  });

  app.get("/api/stats/coverage", (req, res) => {
    // Calculate coverage based on test cases per category
    const coverage = db.prepare(`
      SELECT 
        category as name,
        COUNT(*) as total,
        SUM(CASE WHEN status = 'Passed' THEN 1 ELSE 0 END) as passed
      FROM test_cases
      GROUP BY category
    `).all();

    const formatted = coverage.map(c => ({
      name: c.name,
      coverage: c.total > 0 ? Math.round((c.passed / c.total) * 100) : 0,
      status: (c.passed / c.total) > 0.8 ? 'Passed' : (c.passed / c.total) > 0.5 ? 'Warning' : 'Critical'
    }));

    res.json(formatted);
  });

  // 获取特定测试用例的历史记录
  app.get("/api/test-cases/:id/history", (req, res) => {
    const { id } = req.params;
    const runs = db.prepare(`
      SELECT * FROM test_runs 
      WHERE test_case_id = ? 
      ORDER BY executed_at DESC
    `).all(id);
    res.json(runs);
  });

  // 模拟执行测试用例
  app.post("/api/test-cases/:id/run", (req, res) => {
    const { id } = req.params;
    
    // 1. 更新状态为 Running
    db.prepare("UPDATE test_cases SET status = 'Running' WHERE id = ?").run(id);
    
    // 2. 模拟延迟后决定结果 (这里我们直接同步返回，前端处理动画)
    // 实际生产中这通常是异步的，但为了演示，我们随机生成一个结果
    const results = ['Passed', 'Failed', 'Blocked'];
    const finalResult = results[Math.floor(Math.random() * results.length)];
    
    // 模拟实时报文发送
    const protocols = ['CAN', 'DoIP', 'V2X', 'Ethernet'];
    const protocol = protocols[Math.floor(Math.random() * protocols.length)];
    
    let step = 0;
    const interval = setInterval(() => {
      step++;
      const hex = Array.from({length: 8}, () => Math.floor(Math.random() * 256).toString(16).padStart(2, '0')).join(' ');
      broadcast({
        type: 'SIMULATION_LOG',
        testCaseId: parseInt(id),
        message: `[${protocol}] Frame ${step}: ID=0x${Math.floor(Math.random() * 2048).toString(16)} DATA=[${hex}]`,
        timestamp: new Date().toISOString()
      });
      
      if (step >= 10) {
        clearInterval(interval);
        broadcast({
          type: 'SIMULATION_COMPLETE',
          testCaseId: parseInt(id),
          result: finalResult
        });
      }
    }, 500);

    const logs = `Simulation run at ${new Date().toISOString()}: Initializing... Protocol check... Execution complete. Result: ${finalResult}`;
    
    // 3. 记录运行结果
    const duration = Math.floor(Math.random() * 600) + 60; // 1-11 minutes
    db.prepare("INSERT INTO test_runs (test_case_id, result, logs, duration, executed_by) VALUES (?, ?, ?, ?, ?)")
      .run(id, finalResult, logs, duration, 'Auto-Runner');
      
    // 4. 更新最终状态
    db.prepare("UPDATE test_cases SET status = ? WHERE id = ?").run(finalResult, id);
    
    res.json({ success: true, result: finalResult, logs });
  });

  app.get("/api/settings", (req, res) => {
    const settings = db.prepare("SELECT * FROM settings").all();
    const settingsMap = settings.reduce((acc: any, curr: any) => {
      acc[curr.key] = curr.value === 'true';
      return acc;
    }, {});
    res.json(settingsMap);
  });

  app.patch("/api/settings/:key", (req, res) => {
    const { key } = req.params;
    const { value } = req.body;
    db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)").run(key, String(value));
    res.json({ success: true });
  });

  app.get("/api/defects", (req, res) => {
    const defects = db.prepare("SELECT * FROM defects ORDER BY created_at DESC").all();
    res.json(defects);
  });

  app.get("/api/assets", (req, res) => {
    const assets = db.prepare("SELECT * FROM assets ORDER BY created_at DESC").all();
    res.json(assets);
  });

  app.post("/api/assets", (req, res) => {
    const { name, status, version, type } = req.body;
    if (!name || !status || !type) {
      return res.status(400).json({ error: "Missing required fields" });
    }
    const result = db.prepare("INSERT INTO assets (name, status, version, type) VALUES (?, ?, ?, ?)").run(name, status, version || 'v1.0.0', type);
    res.json({ id: result.lastInsertRowid });
  });

  app.delete("/api/assets/:id", (req, res) => {
    const { id } = req.params;
    db.prepare("DELETE FROM assets WHERE id = ?").run(id);
    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // Seed data if empty
  const count = db.prepare("SELECT COUNT(*) as count FROM test_cases").get().count;
  if (count === 0) {
    const seedCases = [
      { 
        title: "T-Box 车联网单元 CAN 总线压力测试", 
        category: "T-Box", 
        type: "Automated", 
        protocol: "CAN", 
        description: "监控自动化测试运行、ECU 仿真及整车诊断。", 
        status: "Running",
        steps: JSON.stringify([
          "初始化 CAN 总线连接",
          "加载压力测试脚本 v2.1",
          "开始发送高频负载数据 (1000 msg/s)",
          "监控 ECU 响应延迟",
          "记录总线错误帧"
        ])
      },
      { 
        title: "原型车辆-X OTA 更新仿真", 
        category: "整车", 
        type: "Automated", 
        protocol: "OTA", 
        description: "整车 (VIN: WA1...) OTA 更新流程验证。", 
        status: "Passed",
        steps: JSON.stringify([
          "建立与 OTA 服务器的安全连接",
          "下载固件包 (v1.0.4)",
          "验证固件包签名",
          "分发固件至各 ECU",
          "执行更新并重启系统"
        ])
      },
      { 
        title: "ADAS 控制单元 HIL 诊断测试", 
        category: "ADAS", 
        type: "Manual", 
        protocol: "HIL", 
        description: "组件 (ECU) 硬件在环诊断功能验证。", 
        status: "Passed",
        steps: JSON.stringify([
          "连接 HIL 仿真机柜",
          "启动诊断会话 (UDS)",
          "读取故障码 (DTC)",
          "清除故障码并验证",
          "执行 IO 环回测试"
        ])
      },
      { 
        title: "电池管理系统 热失控仿真", 
        category: "BMS", 
        type: "Automated", 
        protocol: "BMS", 
        description: "组件 (BMS) 电池热管理与安全预警测试。", 
        status: "Failed",
        steps: JSON.stringify([
          "模拟电芯温度异常升高",
          "触发热失控预警信号",
          "验证冷却系统启动响应",
          "监控高压切断逻辑",
          "记录系统关断时间"
        ])
      },
      { 
        title: "网关防火墙 渗透测试", 
        category: "Gateway", 
        type: "Manual", 
        protocol: "Ethernet", 
        description: "整车网关安全策略与防火墙规则验证。", 
        status: "Blocked",
        steps: JSON.stringify([
          "扫描开放端口",
          "尝试未授权的 SSH 访问",
          "验证防火墙拦截规则",
          "执行拒绝服务 (DoS) 攻击模拟",
          "分析安全审计日志"
        ])
      }
    ];
    const insert = db.prepare("INSERT INTO test_cases (title, category, type, protocol, description, status, steps) VALUES (?, ?, ?, ?, ?, ?, ?)");
    seedCases.forEach(c => insert.run(c.title, c.category, c.type, c.protocol, c.description, c.status, c.steps));

    // Seed some test runs
    const insertRun = db.prepare("INSERT INTO test_runs (test_case_id, result, logs, duration, executed_by) VALUES (?, ?, ?, ?, ?)");
    insertRun.run(1, 'Running', 'CAN traffic high load...', 765, 'System');
    insertRun.run(2, 'Passed', 'OTA update successful', 192, 'Admin');
    insertRun.run(3, 'Passed', 'Diagnostics clear', 485, 'Tester');
    insertRun.run(4, 'Failed', 'Thermal threshold exceeded', 320, 'System');

    // Seed defects
    const insertDefect = db.prepare("INSERT INTO defects (id, description, module, severity, status) VALUES (?, ?, ?, ?, ?)");
    insertDefect.run('DTC-0821', 'CAN 总线信号丢失 - 转向柱模块', 'GW', 'Critical', 'Open');
    insertDefect.run('SEC-442', '未授权的 SSH 访问尝试', 'T-Box', 'Critical', 'In Review');
    insertDefect.run('LOG-102', '电池包温度传感器读数异常', 'BMS', 'Major', 'Fixed');
    insertDefect.run('UI-009', '中控屏启动动画掉帧', 'IVI', 'Minor', 'Closed');

    // Seed assets
    const insertAsset = db.prepare("INSERT INTO assets (name, status, version, type) VALUES (?, ?, ?, ?)");
    insertAsset.run('GW-01 (Gateway)', 'Online', 'v2.4.1', 'Hardware');
    insertAsset.run('TBOX-PRO-X', 'Online', 'v4.0.2', 'Hardware');
    insertAsset.run('ADAS-SIM-NODE', 'Offline', 'v1.1.0', 'Simulation');
    insertAsset.run('BMS-UNIT-04', 'Online', 'v3.2.2', 'Hardware');
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
