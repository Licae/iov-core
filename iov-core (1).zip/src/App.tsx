import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  PlayCircle, 
  FileWarning, 
  Database, 
  BarChart3, 
  Users, 
  Settings,
  Search,
  Plus,
  Bell,
  ChevronRight,
  MoreHorizontal,
  ShieldCheck,
  AlertTriangle,
  Activity,
  Cpu,
  Car,
  Zap,
  CheckCircle2,
  XCircle,
  Clock,
  Terminal as TerminalIcon,
  BrainCircuit,
  Trash2,
  Edit3
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  CartesianGrid,
  AreaChart,
  Area
} from 'recharts';
import { GoogleGenAI } from "@google/genai";

// --- Types ---
interface TestCase {
  id: number;
  title: string;
  category: string;
  type: 'Automated' | 'Manual';
  protocol: string;
  description: string;
  test_input?: string;
  test_tool?: string;
  expected_result?: string;
  automation_level?: string;
  status: string;
  created_at: string;
  steps?: string; // JSON string
}

interface TestRun {
  id: number;
  test_case_id: number;
  result: string;
  logs: string;
  duration: number;
  executed_by: string;
  executed_at: string;
}

interface Stats {
  total: number;
  automated: number;
  manual: number;
  results: { result: string; count: number }[];
}

// --- Components ---

interface ToastProps {
  message: string;
  type: 'success' | 'error';
  onClose: () => void;
  key?: any;
}

const Toast = ({ message, type, onClose }: ToastProps) => (
  <motion.div
    initial={{ opacity: 0, y: 20, x: 20 }}
    animate={{ opacity: 1, y: 0, x: 0 }}
    exit={{ opacity: 0, scale: 0.95 }}
    className={`fixed bottom-8 right-8 z-[100] flex items-center gap-3 px-4 py-3 rounded-xl border shadow-2xl backdrop-blur-md ${
      type === 'success' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500' : 'bg-red-500/10 border-red-500/20 text-red-500'
    }`}
  >
    {type === 'success' ? <CheckCircle2 size={18} /> : <XCircle size={18} />}
    <span className="text-sm font-medium">{message}</span>
    <button onClick={onClose} className="ml-2 hover:opacity-70 transition-opacity">
      <MoreHorizontal size={14} />
    </button>
  </motion.div>
);

const SidebarItem = ({ icon: Icon, label, active, badge, onClick }: { icon: any, label: string, active?: boolean, badge?: string, onClick: () => void }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center justify-between px-6 py-3 text-sm transition-all relative ${
      active ? 'text-white' : 'text-text-secondary hover:text-white hover:bg-white/5'
    }`}
  >
    <div className="flex items-center gap-3">
      <Icon size={18} className={active ? 'text-accent' : ''} />
      <span className="font-medium">{label}</span>
    </div>
    {badge && (
      <span className="bg-accent/20 text-accent text-[10px] px-1.5 py-0.5 rounded font-bold">
        {badge}
      </span>
    )}
    {active && <div className="absolute left-0 top-0 bottom-0 w-1 bg-accent" />}
  </button>
);

const StatCard = ({ label, value, trend, icon: Icon, color }: { label: string, value: string | number, trend?: string, icon: any, color: string }) => (
  <div className="glass-card p-6 flex-1 min-w-[240px]">
    <div className="flex justify-between items-start mb-4">
      <div className="flex items-center gap-2">
        <div className={`w-2 h-2 rounded-full ${color}`} />
        <span className="text-[12px] text-text-secondary font-medium">{label}</span>
      </div>
      <div className="bg-white/5 p-2 rounded-lg">
        <Icon size={20} className="text-text-secondary" />
      </div>
    </div>
    <div className="flex items-end gap-3">
      <div className="text-3xl font-bold tracking-tight">{value}</div>
      {trend && <div className="text-[11px] text-success font-medium pb-1">{trend}</div>}
    </div>
    <div className="mt-4 text-[10px] text-text-secondary uppercase tracking-wider font-bold">
      {label === '系统可靠性' ? '通过率 +1.2%' : label === '严重缺陷' ? '新增 1 条 DTC 记录' : label === '运行中仿真' ? 'HIL & SIL 测试执行中' : '已监控的 ECU 与车辆'}
    </div>
  </div>
);

export default function App() {
  const [view, setView] = useState<'dashboard' | 'running' | 'defects' | 'assets' | 'reports' | 'management'>('dashboard');
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [managementSearchQuery, setManagementSearchQuery] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAssetModal, setShowAssetModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [showTaskModal, setShowTaskModal] = useState(false);
  const [selectedCaseId, setSelectedCaseId] = useState<number | string>('');
  const [selectedAssetId, setSelectedAssetId] = useState<number | string>('');
  const [importText, setImportText] = useState('');
  const [updatingIds, setUpdatingIds] = useState<number[]>([]);
  const [toasts, setToasts] = useState<{ id: string, message: string, type: 'success' | 'error' }[]>([]);
  const [selectedTestCase, setSelectedTestCase] = useState<TestCase | null>(null);
  const [selectedAsset, setSelectedAsset] = useState<any | null>(null);
  const [history, setHistory] = useState<TestRun[]>([]);
  const [isHistoryLoading, setIsHistoryLoading] = useState(false);
  const [isRunningSimulation, setIsRunningSimulation] = useState(false);
  const [simulationLogs, setSimulationLogs] = useState<any[]>([]);
  const [analyzingDefectId, setAnalyzingDefectId] = useState<string | null>(null);
  const [isUpdatingAsset, setIsUpdatingAsset] = useState(false);
  const [defectAnalysis, setDefectAnalysis] = useState<Record<string, string>>({});
  const [filterProtocol, setFilterProtocol] = useState<string>('All');
  const [trendData, setTrendData] = useState<any[]>([]);
  const [coverageData, setCoverageData] = useState<any[]>([]);
  const [defects, setDefects] = useState<any[]>([]);
  const [assets, setAssets] = useState<any[]>([]);
  const [settings, setSettings] = useState<{ [key: string]: boolean }>({
    abort_on_critical_dtc: true,
    pr_requires_sil: true
  });

  const filteredTestCases = testCases.filter(tc => {
    const matchesSearch = tc.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                         tc.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesProtocol = filterProtocol === 'All' || tc.protocol === filterProtocol;
    return matchesSearch && matchesProtocol;
  });

  useEffect(() => {
    fetchData();

    // Setup WebSocket
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const ws = new WebSocket(`${protocol}//${window.location.host}`);
    
    ws.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'SIMULATION_LOG') {
        if (selectedTestCase?.id === data.testCaseId) {
          setSimulationLogs(prev => [...prev, data].slice(-10));
        }
      } else if (data.type === 'SIMULATION_COMPLETE') {
        fetchData();
        if (selectedTestCase?.id === data.testCaseId) {
          fetchHistory(data.testCaseId);
          setIsRunningSimulation(false);
        }
      }
    };

    return () => ws.close();
  }, [selectedTestCase?.id]);

  const fetchData = async () => {
    try {
      const [casesRes, statsRes, trendRes, coverageRes, defectsRes, assetsRes, settingsRes] = await Promise.all([
        fetch('/api/test-cases'),
        fetch('/api/stats'),
        fetch('/api/stats/trend'),
        fetch('/api/stats/coverage'),
        fetch('/api/defects'),
        fetch('/api/assets'),
        fetch('/api/settings')
      ]);
      const cases = await casesRes.json();
      const statsData = await statsRes.json();
      const trend = await trendRes.json();
      const coverage = await coverageRes.json();
      const defectsData = await defectsRes.json();
      const assetsData = await assetsRes.json();
      const settingsData = await settingsRes.json();
      setTestCases(cases);
      setStats(statsData);
      setTrendData(trend);
      setCoverageData(coverage);
      setDefects(defectsData);
      setAssets(assetsData);
      setSettings(settingsData);
    } catch (error) {
      console.error('Failed to fetch data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDuration = (seconds: number) => {
    if (!seconds) return '--';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}分 ${secs}秒`;
  };

  const addToast = (message: string, type: 'success' | 'error') => {
    const id = `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(t => t.id !== id));
    }, 3000);
  };

  const fetchHistory = async (id: number) => {
    setIsHistoryLoading(true);
    try {
      const res = await fetch(`/api/test-cases/${id}/history`);
      const data = await res.json();
      setHistory(data);
    } catch (error) {
      console.error('Failed to fetch history:', error);
    } finally {
      setIsHistoryLoading(false);
    }
  };

  const runSimulation = async (id: number) => {
    setIsRunningSimulation(true);
    setSimulationLogs([]);
    addToast('正在启动模拟执行引擎...', 'success');
    try {
      const res = await fetch(`/api/test-cases/${id}/run`, { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        await fetchData();
        await fetchHistory(id);
        addToast(`模拟执行完成！结果：${data.result}`, 'success');
        // Update selected test case status locally
        if (selectedTestCase?.id === id) {
          setSelectedTestCase(prev => prev ? { ...prev, status: data.result } : null);
        }
      } else {
        addToast('模拟执行启动失败', 'error');
      }
    } catch (error) {
      console.error('Simulation failed:', error);
      addToast('模拟执行过程中发生错误', 'error');
    } finally {
      setIsRunningSimulation(false);
    }
  };

  const analyzeDefect = async (defect: any) => {
    setAnalyzingDefectId(defect.id);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: `As an automotive cybersecurity and diagnostic expert, analyze this defect captured during a V2X/ECU simulation:
        
        Defect ID: ${defect.id}
        Description: ${defect.description}
        Module: ${defect.module}
        Severity: ${defect.severity}
        
        Provide a concise root cause analysis and 3 specific troubleshooting steps. Format in markdown.`,
      });
      
      setDefectAnalysis(prev => ({ ...prev, [defect.id]: response.text || "无法生成分析结果" }));
    } catch (error) {
      console.error('AI Analysis failed:', error);
      addToast('AI 诊断失败，请检查 API 配置', 'error');
    } finally {
      setAnalyzingDefectId(null);
    }
  };

  const pingAsset = (name: string) => {
    addToast(`正在 Ping 资产 ${name}...`, 'success');
    setTimeout(() => {
      addToast(`资产 ${name} 响应正常 (延迟: ${Math.floor(Math.random() * 50)}ms)`, 'success');
    }, 1000);
  };

  const updateFirmware = (name: string) => {
    setIsUpdatingAsset(true);
    addToast(`正在向 ${name} 推送固件更新包...`, 'success');
    setTimeout(() => {
      setIsUpdatingAsset(false);
      addToast(`资产 ${name} 固件已成功升级至最新版本`, 'success');
    }, 3000);
  };

  const registerAsset = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const assetData = {
      name: formData.get('name'),
      type: formData.get('type'),
      status: 'Online',
      version: formData.get('version') || 'v1.0.0'
    };

    try {
      const res = await fetch('/api/assets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(assetData)
      });
      if (res.ok) {
        addToast('资产注册成功', 'success');
        fetchData();
        setShowAssetModal(false);
      }
    } catch (error) {
      addToast('注册失败', 'error');
    }
  };

  const deleteAsset = async (id: number) => {
    try {
      const res = await fetch(`/api/assets/${id}`, { method: 'DELETE' });
      if (res.ok) {
        addToast('资产已删除', 'success');
        fetchData();
        setSelectedAsset(null);
      }
    } catch (error) {
      addToast('删除失败', 'error');
    }
  };

  const createTestCase = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const steps = (formData.get('steps') as string).split('\n').filter(s => s.trim());
    const newCase = {
      title: formData.get('title'),
      category: formData.get('category'),
      type: formData.get('type'),
      protocol: formData.get('protocol'),
      description: formData.get('description'),
      steps,
      test_input: formData.get('test_input'),
      test_tool: formData.get('test_tool'),
      expected_result: formData.get('expected_result'),
      automation_level: formData.get('automation_level')
    };

    try {
      const res = await fetch('/api/test-cases', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newCase)
      });
      if (res.ok) {
        addToast('测试用例创建成功', 'success');
        fetchData();
        setShowCreateModal(false);
      }
    } catch (error) {
      addToast('创建失败', 'error');
    }
  };

  const createTestTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCaseId || !selectedAssetId) return;

    try {
      const res = await fetch('/api/test-runs', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          test_case_id: selectedCaseId,
          asset_id: selectedAssetId
        })
      });
      if (res.ok) {
        addToast('测试任务已发起', 'success');
        setShowTaskModal(false);
        setView('running');
        fetchData();
      }
    } catch (error) {
      addToast('发起任务失败', 'error');
    }
  };

  const editTestCase = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedTestCase) return;
    const formData = new FormData(e.currentTarget);
    const steps = (formData.get('steps') as string).split('\n').filter(s => s.trim());
    const updatedCase = {
      title: formData.get('title'),
      category: formData.get('category'),
      type: formData.get('type'),
      protocol: formData.get('protocol'),
      description: formData.get('description'),
      steps,
      test_input: formData.get('test_input'),
      test_tool: formData.get('test_tool'),
      expected_result: formData.get('expected_result'),
      automation_level: formData.get('automation_level')
    };

    try {
      const res = await fetch(`/api/test-cases/${selectedTestCase.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updatedCase)
      });
      if (res.ok) {
        addToast('测试用例已更新', 'success');
        fetchData();
        setShowEditModal(false);
        setSelectedTestCase(null);
      }
    } catch (error) {
      addToast('更新失败', 'error');
    }
  };

  const handleImport = async () => {
    const lines = importText.split('\n').filter(l => l.includes('|'));
    if (lines.length < 3) return;

    // Skip header and separator
    const dataLines = lines.slice(2);
    const cases = dataLines.map(line => {
      const parts = line.split('|').map(p => p.trim()).filter(p => p !== '');
      if (parts.length < 7) return null;
      return {
        category: parts[0],
        title: parts[1],
        test_input: parts[2],
        test_tool: parts[3],
        steps: parts[4],
        expected_result: parts[5],
        automation_level: parts[6]
      };
    }).filter(c => c !== null);

    try {
      const res = await fetch('/api/test-cases/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cases })
      });
      if (res.ok) {
        addToast(`成功导入 ${cases.length} 条测试用例`, 'success');
        fetchData();
        setShowImportModal(false);
        setImportText('');
      }
    } catch (error) {
      addToast('导入失败', 'error');
    }
  };

  const deleteTestCase = async (id: number) => {
    // In iframe environment, native confirm might be blocked. 
    // For now, we proceed with deletion to ensure functionality works.
    try {
      const res = await fetch(`/api/test-cases/${id}`, { method: 'DELETE' });
      if (res.ok) {
        addToast('测试用例已删除', 'success');
        fetchData();
        setSelectedTestCase(null);
      }
    } catch (error) {
      addToast('删除失败', 'error');
    }
  };

  const toggleSetting = async (key: string) => {
    const newValue = !settings[key];
    setSettings(prev => ({ ...prev, [key]: newValue }));
    try {
      const res = await fetch(`/api/settings/${key}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ value: newValue })
      });
      if (res.ok) {
        addToast(`设置已更新`, 'success');
      } else {
        addToast('更新设置失败', 'error');
        // Rollback
        setSettings(prev => ({ ...prev, [key]: !newValue }));
      }
    } catch (error) {
      console.error('Failed to update setting:', error);
      addToast('网络错误', 'error');
      setSettings(prev => ({ ...prev, [key]: !newValue }));
    }
  };
  const updateTestCaseStatus = async (id: number, status: string) => {
    setUpdatingIds(prev => [...prev, id]);
    try {
      const res = await fetch(`/api/test-cases/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      if (res.ok) {
        await fetchData();
        addToast(`测试状态已更新为 ${status}`, 'success');
      } else {
        addToast('更新状态失败', 'error');
      }
    } catch (error) {
      console.error('Failed to update status:', error);
      addToast('网络错误，请稍后重试', 'error');
    } finally {
      setUpdatingIds(prev => prev.filter(uid => uid !== id));
    }
  };

  return (
    <div className="flex h-screen bg-bg text-white overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-border flex flex-col bg-bg z-20">
        <div className="p-8">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-accent rounded flex items-center justify-center">
              <Zap size={18} className="text-white" fill="white" />
            </div>
            <h1 className="text-lg font-bold tracking-tighter uppercase">IOV-CORE</h1>
          </div>
        </div>

        <div className="flex-1 py-4">
          <div className="px-8 mb-4 text-[10px] uppercase tracking-widest text-muted font-bold">平台功能</div>
          <nav className="space-y-1">
            <SidebarItem icon={LayoutDashboard} label="仪表盘" active={view === 'dashboard'} onClick={() => setView('dashboard')} />
            <SidebarItem icon={Database} label="用例管理" active={view === 'management'} onClick={() => setView('management')} />
            <SidebarItem icon={PlayCircle} label="仿真执行" badge="2" active={view === 'running'} onClick={() => setView('running')} />
            <SidebarItem icon={FileWarning} label="缺陷日志" active={view === 'defects'} onClick={() => setView('defects')} />
            <SidebarItem icon={Database} label="测试资产" active={view === 'assets'} onClick={() => setView('assets')} />
            <SidebarItem icon={BarChart3} label="分析报告" active={view === 'reports'} onClick={() => setView('reports')} />
          </nav>

          <div className="px-8 mt-8 mb-4 text-[10px] uppercase tracking-widest text-muted font-bold">系统管理</div>
          <nav className="space-y-1">
            <SidebarItem icon={Users} label="团队成员" onClick={() => {}} />
            <SidebarItem icon={Settings} label="偏好设置" onClick={() => {}} />
          </nav>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="h-16 border-b border-border flex items-center justify-between px-8 bg-bg/80 backdrop-blur-md z-10">
          <div className="flex items-center gap-2 text-sm">
            <span className="text-text-secondary">平台</span>
            <ChevronRight size={14} className="text-muted" />
            <span className="text-white font-medium">仪表盘</span>
          </div>

          <div className="flex items-center gap-6">
            <div className="relative group">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted group-focus-within:text-accent transition-colors" size={16} />
              <input 
                type="text" 
                placeholder="搜索 ECU、VIN、DTC..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-card border border-border rounded-lg pl-10 pr-4 py-1.5 text-xs w-64 focus:outline-none focus:border-accent transition-all"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex gap-1">
                <span className="text-[10px] bg-border px-1 rounded text-text-secondary">⌘</span>
                <span className="text-[10px] bg-border px-1 rounded text-text-secondary">K</span>
              </div>
            </div>
            <button className="text-text-secondary hover:text-white transition-colors">
              <Bell size={20} />
            </button>
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-accent to-[#AA44FF]" />
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8 space-y-8">
          {view === 'dashboard' ? (
            <>
              {/* Header Section */}
              <div className="flex justify-between items-end">
                <div>
                  <h2 className="text-2xl font-bold mb-2">车辆与组件测试概览</h2>
                  <p className="text-sm text-text-secondary">监控自动化测试运行、ECU 仿真及整车诊断。</p>
                </div>
                <div className="flex gap-3">
                  <div className="flex bg-card border border-border rounded-lg p-1">
                    {['All', 'CAN', 'Ethernet', 'V2X'].map(p => (
                      <button 
                        key={p}
                        onClick={() => setFilterProtocol(p)}
                        className={`px-3 py-1 rounded-md text-[10px] font-bold transition-all ${filterProtocol === p ? 'bg-accent text-white' : 'text-muted hover:text-white'}`}
                      >
                        {p}
                      </button>
                    ))}
                  </div>
                  <button 
                    onClick={() => setShowTaskModal(true)}
                    className="bg-accent px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 hover:bg-[#4433EE] transition-colors shadow-lg shadow-accent/20"
                  >
                    <Plus size={16} />
                    发起测试任务
                  </button>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="flex gap-6 overflow-x-auto pb-2">
                <StatCard label="系统可靠性" value="94%" trend="通过率 +1.2%" icon={ShieldCheck} color="bg-success" />
                <StatCard label="严重缺陷" value="3" icon={AlertTriangle} color="bg-danger" />
                <StatCard label="运行中仿真" value="2" icon={Activity} color="bg-accent" />
                <StatCard label="测试资产总数" value="142" icon={Database} color="bg-text-secondary" />
              </div>

              {/* Main Dashboard Layout */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Recent Executions */}
                <div className="lg:col-span-2 glass-card overflow-hidden">
                  <div className="p-6 border-b border-border flex justify-between items-center">
                    <h3 className="font-bold">最近测试执行</h3>
                    <button className="text-xs text-accent font-bold flex items-center gap-1 hover:underline">
                      查看全部 <ChevronRight size={14} />
                    </button>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr>
                          <th className="table-header">目标资产</th>
                          <th className="table-header">测试类型</th>
                          <th className="table-header">状态</th>
                          <th className="table-header">测试结果</th>
                          <th className="table-header">耗时</th>
                        </tr>
                      </thead>
                      <tbody className="text-sm">
                        {filteredTestCases.length === 0 ? (
                          <tr>
                            <td colSpan={5} className="py-12 text-center text-muted italic">未找到匹配的测试用例</td>
                          </tr>
                        ) : (
                          filteredTestCases.map((tc, i) => (
                            <tr 
                              key={tc.id} 
                              onClick={() => {
                                setSelectedTestCase(tc);
                                fetchHistory(tc.id);
                              }}
                              className={`table-row cursor-pointer transition-opacity ${updatingIds.includes(tc.id) ? 'opacity-50 pointer-events-none' : ''}`}
                            >
                            <td className="py-4 px-4">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded bg-white/5 flex items-center justify-center">
                                  {tc.category === 'T-Box' ? <Cpu size={16} className="text-text-secondary" /> : <Car size={16} className="text-text-secondary" />}
                                </div>
                                <div>
                                  <div className="font-bold">{tc.title.split(' ')[0]}</div>
                                  <div className="text-[10px] text-muted uppercase">{tc.category} ({tc.protocol})</div>
                                </div>
                              </div>
                            </td>
                            <td className="py-4 px-4">
                              <div className="text-xs">{tc.protocol} 总线压力测试</div>
                            </td>
                            <td className="py-4 px-4">
                              <select 
                                value={tc.status} 
                                onChange={(e) => updateTestCaseStatus(tc.id, e.target.value)}
                                className={`badge ${
                                  tc.status === 'Running' ? 'badge-info' : 
                                  tc.status === 'Passed' ? 'badge-success' : 
                                  tc.status === 'Failed' ? 'badge-danger' : 
                                  tc.status === 'Blocked' ? 'badge-warning' : 'badge-info'
                                } bg-transparent border-none cursor-pointer focus:outline-none appearance-none`}
                              >
                                <option value="Running" className="bg-[#111111]">Running</option>
                                <option value="Passed" className="bg-[#111111]">Passed</option>
                                <option value="Failed" className="bg-[#111111]">Failed</option>
                                <option value="Blocked" className="bg-[#111111]">Blocked</option>
                                <option value="Draft" className="bg-[#111111]">Draft</option>
                              </select>
                            </td>
                            <td className="py-4 px-4">
                              {tc.status === 'Running' ? (
                                <div className="flex items-center gap-2 text-accent">
                                  <motion.div
                                    animate={{ rotate: 360 }}
                                    transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
                                  >
                                    <Zap size={12} />
                                  </motion.div>
                                  <span className="text-[10px] font-bold">执行中...</span>
                                </div>
                              ) : tc.status === 'Failed' ? (
                                <div className="flex items-center gap-2 text-danger">
                                  <AlertTriangle size={12} />
                                  <span className="font-bold text-[10px]">1 严重缺陷</span>
                                </div>
                              ) : tc.status === 'Passed' ? (
                                <div className="flex items-center gap-2 text-success">
                                  <ShieldCheck size={12} />
                                  <span className="font-bold text-[10px]">全部通过</span>
                                </div>
                              ) : tc.status === 'Blocked' ? (
                                <div className="flex items-center gap-2 text-warning">
                                  <Clock size={12} />
                                  <span className="font-bold text-[10px]">已阻塞</span>
                                </div>
                              ) : (
                                <span className="text-muted text-[10px]">未执行</span>
                              )}
                            </td>
                            <td className="py-4 px-4 text-text-secondary font-mono text-xs">
                              {(() => {
                                return formatDuration(tc.id === 1 ? 765 : tc.id === 2 ? 192 : tc.id === 3 ? 485 : tc.id === 4 ? 320 : 0);
                              })()}
                            </td>
                          </tr>
                        )))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Defect Distribution */}
                <div className="flex flex-col gap-8">
                  <div className="glass-card p-6 flex-1">
                    <div className="flex justify-between items-center mb-6">
                      <h3 className="font-bold">执行趋势</h3>
                      <div className="text-[10px] text-muted font-bold uppercase tracking-widest">过去 7 天</div>
                    </div>
                    <div className="h-[180px] w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={trendData}>
                          <defs>
                            <linearGradient id="colorRuns" x1="0" y1="0" x2="0" y2="1">
                              <stop offset="5%" stopColor="#4433EE" stopOpacity={0.3}/>
                              <stop offset="95%" stopColor="#4433EE" stopOpacity={0}/>
                            </linearGradient>
                          </defs>
                          <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                          <XAxis 
                            dataKey="day" 
                            axisLine={false} 
                            tickLine={false} 
                            tick={{ fill: '#888', fontSize: 10 }} 
                            dy={10}
                          />
                          <YAxis hide />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#111', border: '1px solid #333', borderRadius: '8px', fontSize: '10px' }}
                            itemStyle={{ color: '#fff' }}
                          />
                          <Area 
                            type="monotone" 
                            dataKey="runs" 
                            stroke="#4433EE" 
                            fillOpacity={1} 
                            fill="url(#colorRuns)" 
                            strokeWidth={2}
                          />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                  </div>

                  <div className="glass-card p-6 flex-1">
                    <div className="flex justify-between items-center mb-8">
                      <h3 className="font-bold">缺陷分布</h3>
                      <MoreHorizontal size={18} className="text-muted" />
                    </div>
                  <div className="space-y-6">
                    {[
                      { label: '严重', count: 3, color: 'bg-danger', total: 50 },
                      { label: '高危', count: 14, color: 'bg-orange-500', total: 50 },
                      { label: '中危', count: 28, color: 'bg-warning', total: 50 },
                      { label: '低危', count: 42, color: 'bg-slate-500', total: 50 },
                    ].map((item, i) => (
                      <div key={i} className="space-y-2">
                        <div className="flex justify-between text-xs font-bold">
                          <div className="flex items-center gap-2">
                            <div className={`w-1.5 h-1.5 rounded-full ${item.color}`} />
                            <span>{item.label}</span>
                          </div>
                          <span>{item.count}</span>
                        </div>
                        <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                          <motion.div 
                            initial={{ width: 0 }}
                            animate={{ width: `${(item.count / 50) * 100}%` }}
                            transition={{ duration: 1, delay: i * 0.1 }}
                            className={`h-full ${item.color}`}
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                  <button className="w-full mt-8 bg-card border border-border py-2 rounded-lg text-xs font-bold hover:bg-border transition-colors">
                    查看诊断报告
                  </button>
                </div>
              </div>
            </div>

            {/* Automation Rules */}
            <div className="glass-card p-8">
              <h3 className="font-bold mb-2">自动化测试规则</h3>
              <p className="text-xs text-text-secondary mb-8">管理 ECU 固件与车辆网络的流水线触发器。</p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="flex justify-between items-center p-4 rounded-xl border border-border bg-white/2">
                  <div>
                    <div className="font-bold text-sm mb-1">遇到安全关键 DTC 时中止</div>
                    <div className="text-[10px] text-muted">如果抛出严重的故障码，则自动停止仿真测试。</div>
                  </div>
                  <div 
                    onClick={() => toggleSetting('abort_on_critical_dtc')}
                    className={`w-10 h-5 rounded-full relative cursor-pointer transition-colors ${settings.abort_on_critical_dtc ? 'bg-accent' : 'bg-white/10'}`}
                  >
                    <motion.div 
                      animate={{ x: settings.abort_on_critical_dtc ? 20 : 2 }}
                      className="absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm" 
                    />
                  </div>
                </div>

                <div className="flex justify-between items-center p-4 rounded-xl border border-border bg-white/2">
                  <div>
                    <div className="font-bold text-sm mb-1">PR 需通过 SIL 验证</div>
                    <div className="text-[10px] text-muted">强制对所有 ECU 固件的代码提交进行软件在环 (SIL) 验证。</div>
                  </div>
                  <div 
                    onClick={() => toggleSetting('pr_requires_sil')}
                    className={`w-10 h-5 rounded-full relative cursor-pointer transition-colors ${settings.pr_requires_sil ? 'bg-accent' : 'bg-white/10'}`}
                  >
                    <motion.div 
                      animate={{ x: settings.pr_requires_sil ? 20 : 2 }}
                      className="absolute top-0.5 w-4 h-4 bg-white rounded-full shadow-sm" 
                    />
                  </div>
                </div>
              </div>
            </div>
            </>
          ) : view === 'management' ? (
            <div className="space-y-8">
              <div className="flex justify-between items-end">
                <div>
                  <h2 className="text-2xl font-bold mb-2">测试用例管理</h2>
                  <p className="text-sm text-text-secondary">维护全球 V2X 与车载系统安全测试基准库。</p>
                </div>
                <div className="flex gap-3">
                  <div className="relative group">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted group-focus-within:text-accent transition-colors" size={14} />
                    <input 
                      type="text" 
                      placeholder="搜索用例名称、类别或工具..."
                      value={managementSearchQuery}
                      onChange={(e) => setManagementSearchQuery(e.target.value)}
                      className="bg-card border border-border rounded-lg pl-9 pr-4 py-2 text-xs w-64 focus:outline-none focus:border-accent transition-all"
                    />
                  </div>
                  <button 
                    onClick={() => setShowImportModal(true)}
                    className="px-4 py-2 rounded-lg border border-border text-xs font-bold uppercase hover:bg-white/5 transition-colors flex items-center gap-2"
                  >
                    <Plus size={14} /> 批量导入
                  </button>
                  <button 
                    onClick={() => setShowCreateModal(true)}
                    className="bg-accent text-white px-4 py-2 rounded-lg text-xs font-bold uppercase flex items-center gap-2 hover:bg-[#4433EE] transition-colors"
                  >
                    <Plus size={14} /> 新建用例
                  </button>
                </div>
              </div>

              <div className="glass-card overflow-hidden">
                <table className="w-full text-left">
                  <thead>
                    <tr className="border-b border-border bg-white/2">
                      <th className="px-6 py-4 text-[10px] font-bold uppercase text-muted tracking-widest w-16">序号</th>
                      <th className="px-8 py-4 text-[10px] font-bold uppercase text-muted tracking-widest">类别</th>
                      <th className="px-8 py-4 text-[10px] font-bold uppercase text-muted tracking-widest">名称</th>
                      <th className="px-8 py-4 text-[10px] font-bold uppercase text-muted tracking-widest">工具</th>
                      <th className="px-8 py-4 text-[10px] font-bold uppercase text-muted tracking-widest">自动化</th>
                      <th className="px-8 py-4 text-[10px] font-bold uppercase text-muted tracking-widest text-right">操作</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {testCases
                      .filter(tc => 
                        tc.title.toLowerCase().includes(managementSearchQuery.toLowerCase()) ||
                        tc.category.toLowerCase().includes(managementSearchQuery.toLowerCase()) ||
                        (tc.test_tool && tc.test_tool.toLowerCase().includes(managementSearchQuery.toLowerCase()))
                      )
                      .map((tc, index) => (
                      <tr key={tc.id} className="hover:bg-white/2 transition-colors group">
                        <td className="px-6 py-4 text-xs text-muted font-mono">
                          {String(index + 1).padStart(2, '0')}
                        </td>
                        <td className="px-8 py-4">
                          <span className="text-[10px] font-bold uppercase px-2 py-0.5 rounded bg-white/5 text-muted">
                            {tc.category}
                          </span>
                        </td>
                        <td className="px-8 py-4">
                          <div className="font-bold text-sm">{tc.title}</div>
                          <div className="text-[10px] text-muted truncate max-w-xs">{tc.expected_result}</div>
                        </td>
                        <td className="px-8 py-4 text-xs font-mono text-accent">{tc.test_tool || '-'}</td>
                        <td className="px-8 py-4">
                          <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${tc.automation_level === 'A' ? 'bg-success/20 text-success' : 'bg-warning/20 text-warning'}`}>
                            {tc.automation_level || 'B'}
                          </span>
                        </td>
                        <td className="px-8 py-4">
                          <div className="flex gap-2 justify-end opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onClick={() => setSelectedTestCase(tc)} className="p-1.5 hover:bg-white/10 rounded text-muted hover:text-white">
                              <Search size={14} />
                            </button>
                            <button onClick={() => { setSelectedTestCase(tc); setShowEditModal(true); }} className="p-1.5 hover:bg-white/10 rounded text-muted hover:text-white">
                              <Edit3 size={14} />
                            </button>
                            <button onClick={() => deleteTestCase(tc.id)} className="p-1.5 hover:bg-white/10 rounded text-danger/50 hover:text-danger">
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : view === 'running' ? (
            <div className="space-y-8">
              <div className="flex justify-between items-end">
                <div>
                  <h2 className="text-2xl font-bold mb-2">运行中测试任务</h2>
                  <p className="text-sm text-text-secondary">当前正在执行的 HIL/SIL 仿真任务实时监控。</p>
                </div>
                <div className="flex items-center gap-2 bg-success/10 text-success px-3 py-1.5 rounded-lg border border-success/20">
                  <div className="w-2 h-2 rounded-full bg-success animate-pulse" />
                  <span className="text-[10px] font-bold uppercase">集群状态: 正常</span>
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                {testCases.filter(tc => tc.status === 'Running').map((tc, i) => (
                  <div key={tc.id} className="glass-card p-6 flex items-center gap-6">
                    <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center text-accent">
                      <Activity size={24} />
                    </div>
                    <div className="flex-1">
                      <div className="flex justify-between items-start mb-2">
                        <div>
                          <h4 className="font-bold text-lg">{tc.title}</h4>
                          <p className="text-xs text-muted uppercase font-bold tracking-wider">{tc.category} • {tc.protocol}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-xs font-bold text-accent mb-1">进度: {45 + i * 12}%</div>
                          <div className="w-32 h-1.5 bg-white/5 rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${45 + i * 12}%` }}
                              className="h-full bg-accent" 
                            />
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 text-[10px] text-muted font-mono">
                        <span className="flex items-center gap-1"><Clock size={10} /> 已运行: 04:22</span>
                        <span className="flex items-center gap-1"><Zap size={10} /> 吞吐量: 850 msg/s</span>
                        <span className="flex items-center gap-1 text-success"><ShieldCheck size={10} /> 无异常</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <button className="p-2 hover:bg-white/5 rounded-lg text-muted transition-colors">
                        <Settings size={18} />
                      </button>
                      <button className="p-2 hover:bg-danger/10 rounded-lg text-danger transition-colors">
                        <XCircle size={18} />
                      </button>
                    </div>
                  </div>
                ))}
                
                {testCases.filter(tc => tc.status === 'Running').length === 0 && (
                  <div className="glass-card p-20 flex flex-col items-center justify-center text-center space-y-4">
                    <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center text-muted">
                      <Activity size={32} />
                    </div>
                    <div>
                      <h4 className="font-bold text-xl">暂无运行中的仿真</h4>
                      <p className="text-muted text-sm">前往仪表盘启动新的测试任务</p>
                    </div>
                    <button 
                      onClick={() => setView('dashboard')}
                      className="px-6 py-2 bg-accent rounded-lg text-xs font-bold uppercase"
                    >
                      返回仪表盘
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : view === 'defects' ? (
            <div className="space-y-8">
              <div className="flex justify-between items-end">
                <div>
                  <h2 className="text-2xl font-bold mb-2">缺陷与诊断日志</h2>
                  <p className="text-sm text-text-secondary">从测试中捕获的 DTC 故障码与安全漏洞。</p>
                </div>
                <div className="flex gap-2">
                  <button className="px-4 py-2 rounded-lg bg-danger text-white text-xs font-bold uppercase">导出报告</button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="glass-card p-6 border-l-4 border-danger">
                  <div className="text-[10px] font-bold text-danger uppercase mb-1">致命 (Critical)</div>
                  <div className="text-3xl font-bold">03</div>
                  <div className="text-[10px] text-muted mt-2">需要立即修复的安全漏洞</div>
                </div>
                <div className="glass-card p-6 border-l-4 border-warning">
                  <div className="text-[10px] font-bold text-warning uppercase mb-1">严重 (Major)</div>
                  <div className="text-3xl font-bold">12</div>
                  <div className="text-[10px] text-muted mt-2">影响核心功能的逻辑错误</div>
                </div>
                <div className="glass-card p-6 border-l-4 border-accent">
                  <div className="text-[10px] font-bold text-accent uppercase mb-1">一般 (Minor)</div>
                  <div className="text-3xl font-bold">24</div>
                  <div className="text-[10px] text-muted mt-2">非关键性的显示或性能问题</div>
                </div>
              </div>

              <div className="glass-card overflow-hidden">
                <table className="w-full text-left">
                  <thead>
                    <tr className="bg-white/[0.02] text-[10px] uppercase tracking-widest font-bold text-muted">
                      <th className="py-4 px-8 border-b border-border">缺陷 ID</th>
                      <th className="py-4 px-4 border-b border-border">描述</th>
                      <th className="py-4 px-4 border-b border-border">来源模块</th>
                      <th className="py-4 px-4 border-b border-border">严重程度</th>
                      <th className="py-4 px-4 border-b border-border">状态</th>
                      <th className="py-4 px-4 border-b border-border">操作</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {defects.map((defect, i) => (
                      <React.Fragment key={i}>
                        <tr className="hover:bg-white/[0.01] transition-colors">
                          <td className="py-4 px-8 font-mono text-xs font-bold text-accent">{defect.id}</td>
                          <td className="py-4 px-4 text-sm font-medium">{defect.description}</td>
                          <td className="py-4 px-4 text-xs text-muted">{defect.module}</td>
                          <td className="py-4 px-4">
                            <span className={`text-[10px] font-bold px-2 py-1 rounded ${
                              defect.severity === 'Critical' ? 'bg-danger/20 text-danger border border-danger/30' :
                              defect.severity === 'Major' ? 'bg-warning/20 text-warning border border-warning/30' :
                              'bg-accent/20 text-accent border border-accent/30'
                            }`}>
                              {defect.severity}
                            </span>
                          </td>
                          <td className="py-4 px-4 text-xs font-bold uppercase">{defect.status}</td>
                          <td className="py-4 px-4">
                            <button 
                              onClick={() => analyzeDefect(defect)}
                              disabled={analyzingDefectId === defect.id}
                              className="flex items-center gap-2 text-accent hover:text-white transition-colors text-[10px] font-bold uppercase"
                            >
                              {analyzingDefectId === defect.id ? (
                                <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                                  <BrainCircuit size={14} />
                                </motion.div>
                              ) : <BrainCircuit size={14} />}
                              AI 诊断
                            </button>
                          </td>
                        </tr>
                        {defectAnalysis[defect.id] && (
                          <tr>
                            <td colSpan={6} className="px-8 py-4 bg-accent/5 border-y border-accent/10">
                              <div className="flex gap-4">
                                <BrainCircuit size={20} className="text-accent shrink-0 mt-1" />
                                <div className="text-xs text-text-secondary leading-relaxed prose prose-invert prose-sm max-w-none">
                                  <div className="font-bold text-accent mb-2 uppercase tracking-widest">AI 智能分析报告</div>
                                  <div dangerouslySetInnerHTML={{ __html: defectAnalysis[defect.id].replace(/\n/g, '<br/>') }} />
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </React.Fragment>
                    ))}
                    {defects.length === 0 && (
                      <tr>
                        <td colSpan={5} className="py-12 text-center text-muted italic">未发现缺陷记录</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          ) : view === 'reports' ? (
            <div className="space-y-8 pb-20">
              <div className="flex justify-between items-end">
                <div>
                  <h2 className="text-2xl font-bold mb-2">测试分析报告</h2>
                  <p className="text-sm text-text-secondary">多维度的测试质量、效率与覆盖率分析。</p>
                </div>
                <button className="px-4 py-2 rounded-lg border border-border text-xs font-bold uppercase hover:bg-white/5 transition-colors">
                  导出 PDF 报告
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div className="glass-card p-8">
                  <h3 className="text-sm font-bold uppercase tracking-widest text-muted mb-8">测试通过率趋势</h3>
                  <div className="h-[300px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={trendData}>
                        <defs>
                          <linearGradient id="colorPass" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#4433FF" stopOpacity={0.3}/>
                            <stop offset="95%" stopColor="#4433FF" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" stroke="#ffffff05" vertical={false} />
                        <XAxis dataKey="date" stroke="#ffffff20" fontSize={10} tickLine={false} axisLine={false} />
                        <YAxis stroke="#ffffff20" fontSize={10} tickLine={false} axisLine={false} />
                        <Tooltip 
                          contentStyle={{ backgroundColor: '#111', border: '1px solid #333', borderRadius: '8px', fontSize: '10px' }}
                          itemStyle={{ color: '#4433FF' }}
                        />
                        <Area type="monotone" dataKey="passRate" stroke="#4433FF" fillOpacity={1} fill="url(#colorPass)" strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                <div className="glass-card p-8">
                  <h3 className="text-sm font-bold uppercase tracking-widest text-muted mb-8">缺陷严重程度分布</h3>
                  <div className="h-[300px] flex items-center justify-center">
                    <div className="grid grid-cols-2 gap-8 w-full">
                      {[
                        { label: 'Critical', count: 12, color: 'bg-danger' },
                        { label: 'Major', count: 24, color: 'bg-warning' },
                        { label: 'Minor', count: 45, color: 'bg-accent' },
                        { label: 'Low', count: 18, color: 'bg-success' }
                      ].map(item => (
                        <div key={item.label} className="p-6 rounded-2xl bg-white/2 border border-border">
                          <div className="flex items-center gap-2 mb-2">
                            <div className={`w-2 h-2 rounded-full ${item.color}`} />
                            <span className="text-[10px] font-bold uppercase text-muted">{item.label}</span>
                          </div>
                          <div className="text-2xl font-bold">{item.count}</div>
                          <div className="text-[10px] text-muted mt-1">占总数 {Math.round(item.count / 99 * 100)}%</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              <div className="glass-card p-8">
                <h3 className="text-sm font-bold uppercase tracking-widest text-muted mb-8">ECU 模块测试覆盖率</h3>
                <div className="space-y-6">
                  {coverageData.map(ecu => (
                    <div key={ecu.name} className="space-y-2">
                      <div className="flex justify-between items-end">
                        <div className="flex items-center gap-3">
                          <span className="font-bold text-sm">{ecu.name}</span>
                          <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase ${
                            ecu.status === 'Passed' ? 'bg-success/20 text-success' :
                            ecu.status === 'Warning' ? 'bg-warning/20 text-warning' : 'bg-danger/20 text-danger'
                          }`}>{ecu.coverage}% 覆盖</span>
                        </div>
                        <span className="text-[10px] text-muted font-mono">目标: 95%</span>
                      </div>
                      <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                        <motion.div 
                          initial={{ width: 0 }}
                          animate={{ width: `${ecu.coverage}%` }}
                          className={`h-full ${
                            ecu.status === 'Passed' ? 'bg-success' :
                            ecu.status === 'Warning' ? 'bg-warning' : 'bg-danger'
                          }`}
                        />
                      </div>
                    </div>
                  ))}
                  {coverageData.length === 0 && (
                    <div className="py-10 text-center text-muted italic">暂无覆盖率数据</div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-8">
              <div className="flex justify-between items-end">
                <div>
                  <h2 className="text-2xl font-bold mb-2">测试资产库</h2>
                  <p className="text-sm text-text-secondary">管理测试涉及的 ECU、车辆原型与仿真节点。</p>
                </div>
                <button 
                  onClick={() => setShowAssetModal(true)}
                  className="bg-accent text-white px-4 py-2 rounded-lg text-xs font-bold uppercase flex items-center gap-2 hover:bg-[#4433EE] transition-colors"
                >
                  <Plus size={14} /> 注册新资产
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {assets.map((asset, i) => (
                  <div 
                    key={i} 
                    onClick={() => setSelectedAsset(asset)}
                    className="glass-card p-6 space-y-4 cursor-pointer hover:border-accent/50 transition-all group"
                  >
                    <div className="flex justify-between items-start">
                      <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center text-accent group-hover:scale-110 transition-transform">
                        <Cpu size={20} />
                      </div>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${asset.status === 'Online' ? 'bg-success/20 text-success' : 'bg-muted/20 text-muted'}`}>
                        {asset.status}
                      </span>
                    </div>
                    <div>
                      <h4 className="font-bold">{asset.name}</h4>
                      <p className="text-[10px] text-muted uppercase font-bold">{asset.type}</p>
                    </div>
                    <div className="pt-4 border-t border-border flex justify-between items-center">
                      <span className="text-[10px] text-muted font-mono">FW: {asset.version}</span>
                      <div className="flex gap-2">
                        <button 
                          onClick={(e) => { e.stopPropagation(); pingAsset(asset.name); }}
                          className="text-accent hover:underline text-[10px] font-bold uppercase"
                        >
                          Ping
                        </button>
                        <button 
                          onClick={(e) => { e.stopPropagation(); updateFirmware(asset.name); }}
                          className="text-accent hover:underline text-[10px] font-bold uppercase"
                        >
                          升级
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
                {assets.length === 0 && (
                  <div className="col-span-full py-20 text-center text-muted italic">资产库为空</div>
                )}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Create Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-card w-full max-w-md p-8 bg-card"
            >
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xl font-bold tracking-tighter uppercase">新建测试用例</h3>
                <button onClick={() => setShowCreateModal(false)} className="text-muted hover:text-white">
                  <XCircle size={24} />
                </button>
              </div>

              <form onSubmit={createTestCase} className="space-y-4 max-h-[70vh] overflow-y-auto pr-2 scrollbar-hide">
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">用例名称</label>
                  <input name="title" required type="text" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-accent" placeholder="例如：BMS 热失控仿真" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试资产 (分类)</label>
                    <select name="category" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none">
                      <option value="T-Box">T-Box</option>
                      <option value="ADAS">ADAS</option>
                      <option value="BMS">BMS</option>
                      <option value="整车">整车</option>
                      <option value="Gateway">Gateway</option>
                      <option value="OTA升级">OTA升级</option>
                      <option value="CAN总线">CAN总线</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试协议</label>
                    <select name="protocol" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none">
                      <option value="CAN">CAN</option>
                      <option value="DoIP">DoIP</option>
                      <option value="Ethernet">Ethernet</option>
                      <option value="OTA">OTA</option>
                      <option value="V2X">V2X</option>
                      <option value="BLE">BLE</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试类型</label>
                    <select name="type" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none">
                      <option value="Automated">自动化 (Automated)</option>
                      <option value="Manual">手动 (Manual)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">自动化等级</label>
                    <select name="automation_level" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none">
                      <option value="A">A (完全自动)</option>
                      <option value="B">B (半自动)</option>
                      <option value="C">C (人工交互)</option>
                      <option value="D">D (无法自动)</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试工具</label>
                  <input name="test_tool" type="text" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-accent" placeholder="例如：ZCANPRO, Wireshark" />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试输入</label>
                  <input name="test_input" type="text" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-accent" placeholder="例如：合法OTA包、篡改后OTA包" />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">预期结果</label>
                  <textarea name="expected_result" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none h-16" placeholder="描述预期行为..." />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">描述</label>
                  <textarea name="description" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none h-16" placeholder="简述测试目的..." />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试步骤 (每行一步)</label>
                  <textarea name="steps" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm font-mono focus:outline-none h-32" placeholder="步骤 1: ...&#10;步骤 2: ..." />
                </div>
                <button type="submit" className="w-full bg-accent py-3 rounded-lg text-xs font-bold uppercase mt-4 hover:bg-[#4433EE] transition-colors">
                  确认创建
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Task Modal (Launch Test) */}
      <AnimatePresence>
        {showTaskModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-card w-full max-w-md p-8 bg-card"
            >
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xl font-bold tracking-tighter uppercase">发起测试任务</h3>
                <button onClick={() => setShowTaskModal(false)} className="text-muted hover:text-white">
                  <XCircle size={24} />
                </button>
              </div>

              <form onSubmit={createTestTask} className="space-y-6">
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-2 block">选择测试用例</label>
                  <select 
                    required
                    value={selectedCaseId}
                    onChange={(e) => setSelectedCaseId(e.target.value)}
                    className="w-full bg-bg border border-border rounded-lg px-3 py-3 text-sm focus:outline-none focus:border-accent"
                  >
                    <option value="">请选择一个用例...</option>
                    {testCases.map(tc => (
                      <option key={tc.id} value={tc.id}>[{tc.category}] {tc.title}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-2 block">选择执行资产</label>
                  <select 
                    required
                    value={selectedAssetId}
                    onChange={(e) => setSelectedAssetId(e.target.value)}
                    className="w-full bg-bg border border-border rounded-lg px-3 py-3 text-sm focus:outline-none focus:border-accent"
                  >
                    <option value="">请选择一个在线资产...</option>
                    {assets.filter(a => a.status === 'Online').map(a => (
                      <option key={a.id} value={a.id}>{a.name} ({a.type})</option>
                    ))}
                  </select>
                </div>

                <div className="p-4 rounded-xl bg-accent/5 border border-accent/10">
                  <div className="flex items-center gap-3 text-accent mb-2">
                    <Zap size={16} />
                    <span className="text-xs font-bold uppercase tracking-wider">任务预检</span>
                  </div>
                  <p className="text-[10px] text-muted leading-relaxed">
                    发起任务后，系统将自动加载仿真脚本并建立与目标 ECU 的通信链路。预计耗时 2-5 分钟。
                  </p>
                </div>

                <button 
                  type="submit" 
                  disabled={!selectedCaseId || !selectedAssetId}
                  className="w-full bg-accent py-4 rounded-xl text-xs font-bold uppercase hover:bg-[#4433EE] transition-all shadow-lg shadow-accent/20 disabled:opacity-50"
                >
                  立即开始执行
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Import Modal */}
      <AnimatePresence>
        {showImportModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-card w-full max-w-2xl p-8 bg-card"
            >
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xl font-bold tracking-tighter uppercase">批量导入测试用例</h3>
                <button onClick={() => setShowImportModal(false)} className="text-muted hover:text-white">
                  <XCircle size={24} />
                </button>
              </div>

              <div className="space-y-4">
                <p className="text-xs text-muted">请粘贴 Markdown 表格内容（包含表头）：</p>
                <textarea 
                  value={importText}
                  onChange={(e) => setImportText(e.target.value)}
                  className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-xs font-mono focus:outline-none h-64 scrollbar-hide"
                  placeholder="| 测试类别 | 测试项名称 | 测试输入 | 测试工具 | 测试步骤 | 预期结果 | 自动化等级 |&#10;| --- | --- | --- | --- | --- | --- | --- |&#10;| OTA升级 | 升级包完整性校验 | ... |"
                />
                <div className="flex gap-3 pt-4">
                  <button 
                    onClick={() => setShowImportModal(false)}
                    className="flex-1 px-4 py-3 rounded-lg border border-border text-xs font-bold uppercase hover:bg-white/5 transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    onClick={handleImport}
                    disabled={!importText.trim()}
                    className="flex-1 bg-accent text-white px-4 py-3 rounded-lg text-xs font-bold uppercase hover:bg-[#4433EE] transition-colors disabled:opacity-50"
                  >
                    开始导入
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Edit Test Case Modal */}
      <AnimatePresence>
        {showEditModal && selectedTestCase && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-card w-full max-w-md p-8 bg-card"
            >
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xl font-bold tracking-tighter uppercase">编辑测试用例</h3>
                <button onClick={() => setShowEditModal(false)} className="text-muted hover:text-white">
                  <XCircle size={24} />
                </button>
              </div>

              <form onSubmit={editTestCase} className="space-y-4 max-h-[70vh] overflow-y-auto pr-2 scrollbar-hide">
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">用例名称</label>
                  <input name="title" required defaultValue={selectedTestCase.title} type="text" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-accent" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试资产 (分类)</label>
                    <select name="category" defaultValue={selectedTestCase.category} className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none">
                      <option value="T-Box">T-Box</option>
                      <option value="ADAS">ADAS</option>
                      <option value="BMS">BMS</option>
                      <option value="整车">整车</option>
                      <option value="Gateway">Gateway</option>
                      <option value="OTA升级">OTA升级</option>
                      <option value="CAN总线">CAN总线</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试协议</label>
                    <select name="protocol" defaultValue={selectedTestCase.protocol} className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none">
                      <option value="CAN">CAN</option>
                      <option value="DoIP">DoIP</option>
                      <option value="Ethernet">Ethernet</option>
                      <option value="OTA">OTA</option>
                      <option value="V2X">V2X</option>
                      <option value="BLE">BLE</option>
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试类型</label>
                    <select name="type" defaultValue={selectedTestCase.type} className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none">
                      <option value="Automated">自动化 (Automated)</option>
                      <option value="Manual">手动 (Manual)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">自动化等级</label>
                    <select name="automation_level" defaultValue={selectedTestCase.automation_level || 'B'} className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none">
                      <option value="A">A (完全自动)</option>
                      <option value="B">B (半自动)</option>
                      <option value="C">C (人工交互)</option>
                      <option value="D">D (无法自动)</option>
                    </select>
                  </div>
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试工具</label>
                  <input name="test_tool" defaultValue={selectedTestCase.test_tool} type="text" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-accent" />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试输入</label>
                  <input name="test_input" defaultValue={selectedTestCase.test_input} type="text" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-accent" />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">预期结果</label>
                  <textarea name="expected_result" defaultValue={selectedTestCase.expected_result} className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none h-16" />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">描述</label>
                  <textarea name="description" defaultValue={selectedTestCase.description} className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none h-16" />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">测试步骤 (每行一步)</label>
                  <textarea name="steps" defaultValue={JSON.parse(selectedTestCase.steps || '[]').join('\n')} className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm font-mono focus:outline-none h-32" />
                </div>
                <button type="submit" className="w-full bg-accent py-3 rounded-lg text-xs font-bold uppercase mt-4 hover:bg-[#4433EE] transition-colors">
                  保存修改
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Register Asset Modal */}
      <AnimatePresence>
        {showAssetModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-card w-full max-w-md p-8 bg-card"
            >
              <div className="flex justify-between items-start mb-6">
                <h3 className="text-xl font-bold tracking-tighter uppercase">注册新资产</h3>
                <button onClick={() => setShowAssetModal(false)} className="text-muted hover:text-white">
                  <XCircle size={24} />
                </button>
              </div>

              <form onSubmit={registerAsset} className="space-y-4">
                <div>
                  <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">资产名称</label>
                  <input name="name" required type="text" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-accent" placeholder="例如：GW-02 (Gateway)" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">资产类型</label>
                    <select name="type" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none">
                      <option value="Hardware">硬件 (Hardware)</option>
                      <option value="Simulation">仿真 (Simulation)</option>
                      <option value="Prototype">原型车 (Prototype)</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] uppercase font-bold text-text-secondary mb-1 block">固件版本</label>
                    <input name="version" type="text" className="w-full bg-bg border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-accent" placeholder="v1.0.0" />
                  </div>
                </div>
                <button type="submit" className="w-full bg-accent py-3 rounded-lg text-xs font-bold uppercase mt-4 hover:bg-[#4433EE] transition-colors">
                  确认注册
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Asset Detail Modal */}
      <AnimatePresence>
        {selectedAsset && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="glass-card w-full max-w-lg p-8 bg-card"
            >
              <div className="flex justify-between items-start mb-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center text-accent">
                    <Cpu size={24} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold tracking-tighter uppercase">{selectedAsset.name}</h3>
                    <p className="text-[10px] text-muted uppercase font-bold tracking-widest">{selectedAsset.type} • {selectedAsset.status}</p>
                  </div>
                </div>
                <button onClick={() => setSelectedAsset(null)} className="text-muted hover:text-white">
                  <XCircle size={24} />
                </button>
              </div>

              <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-white/2 border border-border">
                    <div className="text-[10px] text-muted uppercase font-bold mb-1">固件版本</div>
                    <div className="font-mono text-sm">{selectedAsset.version}</div>
                  </div>
                  <div className="p-4 rounded-xl bg-white/2 border border-border">
                    <div className="text-[10px] text-muted uppercase font-bold mb-1">最后同步</div>
                    <div className="text-sm">刚刚</div>
                  </div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-xs uppercase font-bold text-muted tracking-widest">实时健康指标</h4>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-[10px] font-bold uppercase mb-1">
                        <span>CPU 负载</span>
                        <span className="text-accent">24%</span>
                      </div>
                      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: '24%' }} className="h-full bg-accent" />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-[10px] font-bold uppercase mb-1">
                        <span>内存占用</span>
                        <span className="text-success">12%</span>
                      </div>
                      <div className="h-1 bg-white/5 rounded-full overflow-hidden">
                        <motion.div initial={{ width: 0 }} animate={{ width: '12%' }} className="h-full bg-success" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <button 
                    onClick={() => deleteAsset(selectedAsset.id)}
                    className="flex-1 py-3 rounded-xl border border-danger/30 text-danger font-bold text-xs uppercase hover:bg-danger/5 transition-colors"
                  >
                    删除资产
                  </button>
                  <button 
                    onClick={() => pingAsset(selectedAsset.name)}
                    className="flex-1 py-3 rounded-xl border border-border font-bold text-xs uppercase hover:bg-white/5 transition-colors"
                  >
                    Ping 测试
                  </button>
                  <button 
                    onClick={() => updateFirmware(selectedAsset.name)}
                    disabled={isUpdatingAsset}
                    className="flex-1 py-3 rounded-xl bg-accent text-white font-bold text-xs uppercase hover:bg-[#4433EE] transition-colors disabled:opacity-50"
                  >
                    {isUpdatingAsset ? '正在升级...' : '固件升级'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Toasts */}
      <AnimatePresence>
        {toasts.map(toast => (
          <Toast 
            key={toast.id} 
            message={toast.message} 
            type={toast.type} 
            onClose={() => setToasts(prev => prev.filter(t => t.id !== toast.id))} 
          />
        ))}
      </AnimatePresence>

      {/* Detail Drawer */}
      <AnimatePresence>
        {selectedTestCase && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedTestCase(null)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60]"
            />
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-full max-w-xl bg-bg border-l border-border z-[70] flex flex-col shadow-2xl"
            >
              <div className="p-6 border-b border-border flex justify-between items-center">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-white/5 flex items-center justify-center">
                    {selectedTestCase.category === 'T-Box' ? <Cpu size={20} className="text-accent" /> : <Car size={20} className="text-accent" />}
                  </div>
                  <div>
                    <h3 className="font-bold text-lg leading-tight">{selectedTestCase.title}</h3>
                    <p className="text-xs text-muted uppercase tracking-wider font-bold">{selectedTestCase.category} • {selectedTestCase.protocol}</p>
                  </div>
                </div>
                <button onClick={() => setSelectedTestCase(null)} className="p-2 hover:bg-white/5 rounded-full transition-colors">
                  <XCircle size={24} className="text-muted" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 space-y-8">
                {/* Actions */}
                <div className="flex gap-3">
                  <button 
                    onClick={() => runSimulation(selectedTestCase.id)}
                    disabled={isRunningSimulation || selectedTestCase.status === 'Running'}
                    className={`flex-1 py-3 rounded-xl font-bold text-xs uppercase flex items-center justify-center gap-2 transition-all ${
                      isRunningSimulation || selectedTestCase.status === 'Running'
                        ? 'bg-white/5 text-muted cursor-not-allowed'
                        : 'bg-accent text-white hover:bg-[#4433EE] shadow-lg shadow-accent/20'
                    }`}
                  >
                    {isRunningSimulation ? (
                      <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: "linear" }}>
                        <Activity size={16} />
                      </motion.div>
                    ) : <PlayCircle size={16} />}
                    {isRunningSimulation ? '正在执行模拟...' : '立即执行测试'}
                  </button>
                  <button 
                    onClick={() => setShowEditModal(true)}
                    className="px-4 py-3 rounded-xl border border-border font-bold text-xs uppercase hover:bg-white/5 transition-colors flex items-center gap-2"
                  >
                    <Edit3 size={16} />
                    编辑用例
                  </button>
                  <button 
                    onClick={() => deleteTestCase(selectedTestCase.id)}
                    className="px-4 py-3 rounded-xl border border-danger/20 text-danger font-bold text-xs uppercase hover:bg-danger/5 transition-colors"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>

                {/* Simulation Terminal */}
                {isRunningSimulation && (
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h4 className="text-xs font-bold text-muted uppercase tracking-widest">实时仿真终端</h4>
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                        <span className="text-[10px] text-accent font-bold">报文流同步中...</span>
                      </div>
                    </div>
                    <div className="bg-black/40 rounded-xl border border-white/5 p-4 font-mono text-[10px] space-y-1 h-48 overflow-y-auto scrollbar-hide">
                      {simulationLogs.length === 0 ? (
                        <div className="text-muted italic">等待报文流...</div>
                      ) : (
                        simulationLogs.map((log, i) => (
                          <div key={i} className="flex gap-3">
                            <span className="text-muted">[{new Date(log.timestamp).toLocaleTimeString()}]</span>
                            <span className="text-accent">{log.message}</span>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}

                {/* Info Grid */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 rounded-xl bg-white/2 border border-border">
                    <div className="text-[10px] text-muted uppercase font-bold mb-1">当前状态</div>
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${
                        selectedTestCase.status === 'Passed' ? 'bg-success' :
                        selectedTestCase.status === 'Failed' ? 'bg-danger' :
                        selectedTestCase.status === 'Running' ? 'bg-accent' : 'bg-warning'
                      }`} />
                      <span className="font-bold text-sm">{selectedTestCase.status}</span>
                    </div>
                  </div>
                  <div className="p-4 rounded-xl bg-white/2 border border-border">
                    <div className="text-[10px] text-muted uppercase font-bold mb-1">自动化等级</div>
                    <div className="font-bold text-sm">{selectedTestCase.automation_level || 'B'}</div>
                  </div>
                  <div className="p-4 rounded-xl bg-white/2 border border-border">
                    <div className="text-[10px] text-muted uppercase font-bold mb-1">测试工具</div>
                    <div className="font-bold text-sm font-mono text-accent">{selectedTestCase.test_tool || '-'}</div>
                  </div>
                  <div className="p-4 rounded-xl bg-white/2 border border-border">
                    <div className="text-[10px] text-muted uppercase font-bold mb-1">测试类型</div>
                    <div className="font-bold text-sm">{selectedTestCase.type}</div>
                  </div>
                </div>

                {/* Expected Result */}
                {selectedTestCase.expected_result && (
                  <div className="space-y-3">
                    <h4 className="text-xs uppercase font-bold text-muted tracking-widest">预期结果</h4>
                    <div className="text-sm text-emerald-400 leading-relaxed bg-emerald-500/5 p-4 rounded-xl border border-emerald-500/10">
                      {selectedTestCase.expected_result}
                    </div>
                  </div>
                )}

                {/* Test Input */}
                {selectedTestCase.test_input && (
                  <div className="space-y-3">
                    <h4 className="text-xs uppercase font-bold text-muted tracking-widest">测试输入</h4>
                    <div className="text-sm text-text-secondary leading-relaxed bg-white/2 p-4 rounded-xl border border-border font-mono">
                      {selectedTestCase.test_input}
                    </div>
                  </div>
                )}

                {/* Description */}
                <div className="space-y-3">
                  <h4 className="text-xs uppercase font-bold text-muted tracking-widest">用例描述</h4>
                  <p className="text-sm text-text-secondary leading-relaxed bg-white/2 p-4 rounded-xl border border-border">
                    {selectedTestCase.description}
                  </p>
                </div>

                {/* Steps */}
                <div className="space-y-4">
                  <h4 className="text-xs uppercase font-bold text-muted tracking-widest">测试步骤</h4>
                  <div className="space-y-2">
                    {(() => {
                      try {
                        const steps = JSON.parse(selectedTestCase.steps || '[]');
                        return steps.map((step: string, index: number) => (
                          <div key={index} className="flex gap-3 items-start p-3 rounded-xl bg-white/2 border border-border">
                            <div className="w-5 h-5 rounded-full bg-accent/20 text-accent flex items-center justify-center text-[10px] font-bold shrink-0 mt-0.5">
                              {index + 1}
                            </div>
                            <span className="text-sm text-text-secondary">{step}</span>
                          </div>
                        ));
                      } catch (e) {
                        return <div className="text-xs text-muted italic">无法解析测试步骤</div>;
                      }
                    })()}
                  </div>
                </div>

                {/* History */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <h4 className="text-xs uppercase font-bold text-muted tracking-widest">执行历史</h4>
                    {isHistoryLoading && <Activity size={14} className="animate-spin text-accent" />}
                  </div>
                  
                  <div className="space-y-3">
                    {history.length === 0 ? (
                      <div className="text-center py-8 text-muted text-sm italic">暂无执行记录</div>
                    ) : (
                      history.map((run) => (
                        <div key={run.id} className="p-4 rounded-xl border border-border bg-white/2 hover:bg-white/5 transition-colors group">
                          <div className="flex justify-between items-start mb-2">
                            <div className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                              run.result === 'Passed' ? 'bg-success/20 text-success' :
                              run.result === 'Failed' ? 'bg-danger/20 text-danger' : 'bg-warning/20 text-warning'
                            }`}>
                              {run.result}
                            </div>
                            <span className="text-[10px] text-muted font-mono">{new Date(run.executed_at).toLocaleString()}</span>
                          </div>
                          <p className="text-xs text-text-secondary line-clamp-2 group-hover:line-clamp-none transition-all">
                            {run.logs || '无详细日志内容'}
                          </p>
                          <div className="mt-2 text-[10px] text-muted font-bold">执行人: {run.executed_by}</div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
